				-----New Cursor-----

This mod changes the arrow cursor to a dagger
	

				-----Installation------

Drag the contents of this zip file to you Kingdom Come Delevierance folder:
	Note:Below is an example filepath of your game for STEAM

C:\Program Files (x86)\Steam\SteamApps\common\KingdomComeDeliverance

You may also do a search for the game directory to find it

				------UnInstallation-------
Go into the mods folder in your Kingdom Come Delieverence folder and delete the folder NewCursor

				   -----Modders-----
Feel Free to Use this as you like


